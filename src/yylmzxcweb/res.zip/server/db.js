/* ============================================================
   YYLMZXC 导航站 · 数据访问层（MySQL）
   自动建库建表；首次启动时用出厂数据 nav-default.js 填充。
   库 / 表被删掉（例如手工 DROP DATABASE）后不必重启后端：
   下一次请求会重新建库建表并重试，只是数据只能回到出厂数据。
   数据模型：内容三张表 settings(单行) / groups / links，
   外加账号与会话两张表：账号密码只存在这里，浏览器不保存任何凭据。
   出厂数据文件本身的读写属于另一职责，见 staticdata.js；
   密码哈希与会话策略属于账号服务，见 account.js；
   连接参数统一读自 config.json，见 config.js。
   ============================================================ */
'use strict';

const mysql = require('mysql2/promise');
const CONFIG = require('./config');
const staticdata = require('./staticdata');

const DB_NAME = CONFIG.mysql.database || 'yylmzxc_nav';

// 默认头像：没有自定义头像时使用本机图片（与前端 Nav.util.DEFAULT_AVATAR 保持一致）
const DEFAULT_AVATAR = 'res/img.png';
// 旧版出厂默认头像（外部链接）；库里仍是它时一次性订正为 DEFAULT_AVATAR（见 connect）
const LEGACY_DEFAULT_AVATAR = 'https://lh3.googleusercontent.com/a/ACg8ocKdGmvHcgUM-klYHYHRKbdhiLZl9ird-CyADSrQgrWHPQ=s96-c';

let pool = null;
let ready = null;    // 建库建表的进行中 / 已完成状态（见 init）
let lastError = null; // 最近一次连接失败的原因（见 diagnose），health 如实转述给前端

/* ---------------- 建库 / 建表 ---------------- */

function baseOptions() {
  return {
    host: CONFIG.mysql.host,
    port: CONFIG.mysql.port,
    user: CONFIG.mysql.user,
    password: CONFIG.mysql.password,
    charset: 'utf8mb4',
    waitForConnections: true,
    connectionLimit: CONFIG.mysql.connectionLimit || 5,
    queueLimit: 0
  };
}

const DDL = [
  `CREATE TABLE IF NOT EXISTS nav_settings (
     id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
     title VARCHAR(255) NOT NULL DEFAULT '',
     description TEXT,
     background TEXT,
     profile_name VARCHAR(255) NOT NULL DEFAULT '',
     profile_avatar TEXT,
     profile_links LONGTEXT,
     updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
   ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

  `CREATE TABLE IF NOT EXISTS nav_groups (
     id VARCHAR(64) NOT NULL PRIMARY KEY,
     name VARCHAR(255) NOT NULL DEFAULT '',
     sort_order INT NOT NULL DEFAULT 0,
     collapsed TINYINT(1) NOT NULL DEFAULT 0,
     column_index INT NOT NULL DEFAULT 0
   ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

  `CREATE TABLE IF NOT EXISTS nav_links (
     id VARCHAR(64) NOT NULL PRIMARY KEY,
     group_id VARCHAR(64) NOT NULL,
     title VARCHAR(512) NOT NULL DEFAULT '',
     url VARCHAR(1024) NOT NULL DEFAULT '',
     favicon VARCHAR(1024) NOT NULL DEFAULT '',
     is_rss TINYINT(1) NOT NULL DEFAULT 0,
     sort_order INT NOT NULL DEFAULT 0,
     KEY idx_nav_links_group (group_id),
     CONSTRAINT fk_nav_links_group FOREIGN KEY (group_id)
       REFERENCES nav_groups (id) ON DELETE CASCADE
   ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

  // 账号只有一行（id = 1）。只存 scrypt 加盐哈希，明文密码不落库
  `CREATE TABLE IF NOT EXISTS nav_account (
     id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
     username VARCHAR(64) NOT NULL DEFAULT '',
     password_hash CHAR(128) NOT NULL DEFAULT '',
     salt CHAR(32) NOT NULL DEFAULT '',
     updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
   ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

  // 登录态令牌：落库才能被服务端随时撤销（退出登录 / 改密码）
  `CREATE TABLE IF NOT EXISTS nav_sessions (
     token CHAR(64) NOT NULL PRIMARY KEY,
     expires_at DATETIME NOT NULL,
     created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
     KEY idx_nav_sessions_expires (expires_at)
   ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`
];

/* ---------------- 连接失败的诊断 ----------------
   MySQL 出问题翻来覆去就那几种，但原始报错长得都一个样。这里把错误码翻译成
   「哪种毛病 + 卡在哪一步 + 怎么办」，供后端日志、/api/health 与前端提示共用：
     server-down  服务没启动（端口没人监听）
     unreachable  网络不通 / 地址写错
     auth         账号密码不对、认证方式不支持
     privilege    账号能用，但没有这个库 / 表的权限
     missing      库或表不存在
     too-many     连接数满了
   ============================================ */

// 连接目标的展示形式：出错时直接打出来，省得再去翻 config.json
const TARGET = CONFIG.mysql.user + '@' + CONFIG.mysql.host + ':' + CONFIG.mysql.port + '/' + DB_NAME;

// 毛病的大类：日志标题、前端提示都取这里的短句，避免各写各的
const KIND_TEXT = {
  'server-down': '数据库服务未启动',
  'unreachable': '连不上数据库服务',
  'auth': 'MySQL 账号或密码不对',
  'privilege': 'MySQL 没有授权访问这个数据库',
  'missing': '数据库或数据表不存在',
  'too-many': 'MySQL 连接数已满',
  'sql': '数据库版本不兼容',
  'unknown': '连接数据库失败'
};

// 出错时所处的环节：同一个错误码在不同环节含义不同，说法要跟着变
const STAGE_TEXT = {
  'connect': '连接 MySQL 服务',
  'create-db': '创建数据库 ' + DB_NAME,
  'ddl': '创建数据表',
  'seed': '写入出厂数据',
  'load': '读取数据',
  'save': '写入数据'
};

// 错误码 → { kind, reason, hint }。reason 一句话说清毛病，hint 是可以照着做的下一步。
const TROUBLE = {
  // ---- 服务没启动 / 连不上 ----
  ECONNREFUSED: {
    kind: 'server-down',
    reason: 'MySQL 拒绝了连接：这个端口上没有服务在监听',
    hint: '基本上是 MySQL 没启动。小皮面板里启动 MySQL，再重新运行本脚本。'
  },
  ENOTFOUND: {
    kind: 'unreachable',
    reason: '解析不到 config.json 里写的 MySQL 主机名',
    hint: '把 mysql.host 改成本机地址 127.0.0.1。'
  },
  EHOSTUNREACH: {
    kind: 'unreachable',
    reason: '网络到不了 config.json 里写的 MySQL 主机',
    hint: '核对该主机的地址与端口（mysql.host / mysql.port）是否写错。'
  },
  ENETUNREACH: {
    kind: 'unreachable',
    reason: '网络到不了 config.json 里写的 MySQL 主机',
    hint: '核对该主机的地址与端口（mysql.host / mysql.port）是否写错。'
  },
  ETIMEDOUT: {
    kind: 'unreachable',
    reason: '连接 MySQL 超时',
    hint: '端口被防火墙拦了，或 mysql.host / mysql.port 写错。'
  },
  ECONNRESET: {
    kind: 'unreachable',
    reason: '连接被 MySQL 重置',
    hint: '多半是 MySQL 刚重启或连接被打满，稍后重试；持续出现请看 MySQL 的错误日志。'
  },
  PROTOCOL_CONNECTION_LOST: {
    kind: 'unreachable',
    reason: '和 MySQL 的连接被中断',
    hint: '确认 MySQL 进程没有崩溃或被重启过。'
  },

  // ---- 账号与认证 ----
  ER_ACCESS_DENIED_ERROR: {
    kind: 'auth',
    reason: 'MySQL 拒绝了这个账号：用户名或密码不对',
    hint: '改 server/config.json 里的 mysql.user / mysql.password，和面板里 MySQL 的账号密码保持一致。'
  },
  ER_ACCESS_DENIED_NO_PASSWORD_ERROR: {
    kind: 'auth',
    reason: '这个账号需要密码，但 config.json 里没有填',
    hint: '在 server/config.json 里补上 mysql.password。'
  },
  ER_HOST_NOT_PRIVILEGED: {
    kind: 'auth',
    reason: 'MySQL 不允许从这个来源地址登录该账号',
    hint: '该账号只允许从别的主机登录。在面板里把它改成允许 %（任意来源）或 127.0.0.1，或换一个允许本机登录的账号。'
  },
  ER_NOT_SUPPORTED_AUTH_MODE: {
    kind: 'auth',
    reason: '账号的认证方式当前客户端不支持（MySQL 8 默认的 caching_sha2_password）',
    hint: '把该用户改成 mysql_native_password：ALTER USER 用户名@主机 IDENTIFIED WITH mysql_native_password BY "密码";'
  },

  // ---- 权限不足 ----
  ER_DBACCESS_DENIED_ERROR: {
    kind: 'privilege',
    reason: '这个账号存在，但没有访问该数据库的权限',
    hint: '用 root 给它授权（GRANT ALL PRIVILEGES ON 库名.* TO 账号;），或把 config.json 的 mysql.user 换成 root。'
  },
  ER_TABLEACCESS_DENIED_ERROR: {
    kind: 'privilege',
    reason: '这个账号没有操作数据表的权限',
    hint: '给该账号授予该库的 SELECT / INSERT / UPDATE / DELETE / CREATE 权限。'
  },
  ER_CANT_CREATE_DB: {
    kind: 'privilege',
    reason: '这个账号没有创建数据库的权限',
    hint: '用 root 先手动建好库，或把 config.json 里的 mysql.user 换成 root。'
  },

  // ---- 库 / 表不存在 ----
  ER_BAD_DB_ERROR: {
    kind: 'missing',
    reason: '这个数据库不存在',
    hint: '后端会自己建库，但账号得先有 CREATE 权限；也可以先用 root 手动建库再启动。'
  },
  ER_NO_SUCH_TABLE: {
    kind: 'missing',
    reason: '数据表不存在',
    hint: '后端会自己建表；反复出现说明这个账号没有建表权限。'
  },
  ER_NO_DB_ERROR: {
    kind: 'missing',
    reason: '没有选择要操作的数据库',
    hint: '检查 server/config.json 里的 mysql.database 是否为空。'
  },

  // ---- 连接数 ----
  ER_CON_COUNT_ERROR: {
    kind: 'too-many',
    reason: 'MySQL 的并发连接数已满',
    hint: '在面板里调大 MySQL 的 max_connections，或稍后重试。'
  },
  ER_TOO_MANY_USER_CONNECTIONS: {
    kind: 'too-many',
    reason: '这个账号的并发连接数已满',
    hint: '在面板里调大该账号的 max_user_connections。'
  },

  // ---- 版本 / SQL ----
  ER_PARSE_ERROR: {
    kind: 'sql',
    reason: 'SQL 语法错误',
    hint: '通常是数据库版本过老，本项目需要 MySQL 5.7 及以上。'
  },
  ER_UNKNOWN_CHARACTER_SET: {
    kind: 'sql',
    reason: '数据库不认识 utf8mb4 字符集',
    hint: '数据库版本过老，本项目需要 MySQL 5.7 及以上。'
  },

  // 后端自己合成的码：建库被拒，而库也确实不存在
  NAV_NO_PRIV_AND_MISSING: {
    kind: 'privilege',
    reason: '这个账号没有创建数据库的权限，而且这个库也还不存在',
    hint: '用 root 手动建库，或把 server/config.json 里的 mysql.user 换成 root。'
  }
};

function safeName() {
  return DB_NAME.replace(/`/g, '');
}

// 建库被权限拦下时 MySQL 报的就是这两个码
function isDenied(e) {
  const code = e && e.code;
  return code === 'ER_DBACCESS_DENIED_ERROR' || code === 'ER_CANT_CREATE_DB';
}

function errorCode(e) {
  if (!e) return '';
  return String(e.code || e.errno || '');
}

// 把任意一个数据库错误翻译成诊断结论
function diagnose(e, stage) {
  const code = errorCode(e);
  const known = TROUBLE[code];

  let kind = known ? known.kind : 'unknown';
  let reason = known ? known.reason : String((e && (e.sqlMessage || e.message)) || '未知错误');
  let hint = known ? known.hint
    : '看后端窗口里的完整报错；若与数据库有关，核对 server/config.json 的 mysql 段并确认 MySQL 已启动。';

  // 建库环节被拒，说的是「没有建库权限」，不是「没有这个库的权限」
  if (stage === 'create-db' && code === 'ER_DBACCESS_DENIED_ERROR') {
    kind = 'privilege';
    reason = '这个账号没有创建数据库 ' + DB_NAME + ' 的权限';
    hint = '用 root 先手动建好这个库，或把 server/config.json 里的 mysql.user 换成 root。';
  }

  return {
    code: code || 'UNKNOWN',
    kind: kind,
    label: KIND_TEXT[kind] || KIND_TEXT.unknown,
    stage: stage || '',
    stageText: STAGE_TEXT[stage] || '',
    reason: reason,
    hint: hint,
    detail: String((e && (e.sqlMessage || e.message)) || ''),
    target: TARGET,
    configFile: 'server/config.json'
  };
}

// 任何数据库错误都能被解释：初始化时抛出的错误已经带着结论，其余现算
function explain(e, stage) {
  if (e && e.dbError) return e.dbError;
  return diagnose(e, stage);
}

// 建库被拒 + 库也打不开：合成一个更准确的错误码，免得把结论说成「库不存在」
function deniedAndMissing() {
  const e = new Error('这个账号没有创建数据库的权限，而且库 ' + DB_NAME + ' 也还不存在');
  e.code = 'NAV_NO_PRIV_AND_MISSING';
  return e;
}

/* ---------------- 初始化与自愈 ---------------- */

// 建库 + 建表 + 空库时填充出厂数据。只负责「把库表准备好」，可重复执行。
// stage 记录出错时走到了哪一步：同样是权限不足，建库和写数据的提示完全不同（见 diagnose）。
async function connect() {
  let stage = 'connect';
  try {
    const root = await mysql.createConnection(baseOptions());
    try {
      stage = 'create-db';
      try {
        await root.query(
          'CREATE DATABASE IF NOT EXISTS `' + safeName() +
          '` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci'
        );
      } catch (e) {
        // MySQL 对 CREATE DATABASE IF NOT EXISTS 也会先校验 CREATE 权限：
        // 库已存在、但账号只有库内权限时会报 1044。这不算失败——探一下能不能直接打开，
        // 能打开就继续用（真正打不开时下面会抛「没权限建库 + 库也不存在」）。
        if (!isDenied(e)) throw e;
        try {
          await root.query('USE `' + safeName() + '`');
        } catch (e2) {
          throw deniedAndMissing();
        }
      }
    } finally {
      await root.end();
    }

    stage = 'ddl';
    pool = mysql.createPool(Object.assign({ database: DB_NAME }, baseOptions()));
    for (const sql of DDL) await pool.query(sql);

    stage = 'seed';
    const [rows] = await pool.query('SELECT id FROM nav_settings WHERE id = 1');
    if (!rows.length) {
      const d = staticdata.read();
      if (d) {
        await writeAll(d);
        console.log('已用出厂数据初始化数据库');
      }
    }

    // 默认头像由「外部链接」改为本机图片 res/img.png：老库里仍留着那个出厂链接时订正过来。
    // 只认出厂值，用户自己填的头像链接不动；改完再启动就匹配不到，等于只跑一次。
    const [fixed] = await pool.query(
      'UPDATE nav_settings SET profile_avatar = ? WHERE id = 1 AND profile_avatar = ?',
      [DEFAULT_AVATAR, LEGACY_DEFAULT_AVATAR]
    );
    if (fixed.affectedRows) console.log('默认头像已改为 ' + DEFAULT_AVATAR);

    lastError = null;
  } catch (e) {
    lastError = diagnose(e, stage);
    const err = new Error(lastError.reason);
    err.code = lastError.code;
    err.dbError = lastError;
    throw err;
  }
}

// 初始化只做一次；失败不缓存，下一次请求还能再试。
function init() {
  if (!ready) {
    ready = connect().catch(function (e) {
      ready = null;
      throw e;
    });
  }
  return ready;
}

// 库或表被删掉时 MySQL 报的就是这两个错，此时重建即可继续用
function isLost(e) {
  const code = e && e.code;
  return code === 'ER_BAD_DB_ERROR' || code === 'ER_NO_SUCH_TABLE';
}

// 所有查询的统一入口：发现库 / 表不见了就先重建再重试一次，
// 所以运行中手工删库不必重启后端（代价是数据只能回到出厂数据）。
async function run(query) {
  await init();
  try {
    return await query(pool);
  } catch (e) {
    if (!isLost(e)) throw e;
    pool = null;
    ready = null;
    await init();
    return query(pool);
  }
}

// 单条 SQL 的语法糖，只取行集
async function q(sql, params) {
  const result = await run(function (p) { return p.query(sql, params); });
  return result[0];
}

/* ---------------- 读取 ---------------- */

function safeParse(text, fallback) {
  try { return JSON.parse(text); } catch (e) { return fallback; }
}

async function loadNav() {
  const settings = await q('SELECT * FROM nav_settings WHERE id = 1');
  if (!settings.length) return null;
  const s = settings[0];

  const groupRows = await q('SELECT * FROM nav_groups ORDER BY sort_order, id');
  const linkRows = await q('SELECT * FROM nav_links ORDER BY sort_order, id');

  const buckets = {};
  linkRows.forEach(function (l) {
    (buckets[l.group_id] = buckets[l.group_id] || []).push(l);
  });

  return {
    version: 1,
    title: s.title || '导航',
    description: s.description || '',
    background: s.background || '',
    profile: {
      name: s.profile_name || '',
      avatar: s.profile_avatar || '',
      links: safeParse(s.profile_links, [])
    },
    groups: groupRows.map(function (g) {
      var group = {
        id: g.id,
        name: g.name,
        column: g.column_index,
        links: (buckets[g.id] || []).map(function (l) {
          const link = { id: l.id, title: l.title, url: l.url };
          if (l.favicon) link.favicon = l.favicon;
          if (l.is_rss) link.rss = true;
          return link;
        })
      };
      if (g.collapsed) group.collapsed = true;   // 仅收起时写入，保持导出文件干净
      return group;
    })
  };
}

/* ---------------- 写入（整份覆盖，事务） ---------------- */

// 真正落库的那一段：调用前连接池必须已就绪（connect 与 saveNav 都已经等过 init）
async function writeAll(data) {
  const profile = data.profile || {};
  const groups = Array.isArray(data.groups) ? data.groups : [];

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    // 先删子表再删父表，避免外键约束
    await conn.query('DELETE FROM nav_links');
    await conn.query('DELETE FROM nav_groups');

    await conn.query(
      `INSERT INTO nav_settings
         (id, title, description, background, profile_name, profile_avatar, profile_links)
       VALUES (1, ?, ?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE
         title = VALUES(title),
         description = VALUES(description),
         background = VALUES(background),
         profile_name = VALUES(profile_name),
         profile_avatar = VALUES(profile_avatar),
         profile_links = VALUES(profile_links)`,
      [
        String(data.title || ''),
        String(data.description || ''),
        String(data.background || ''),
        String(profile.name || ''),
        String(profile.avatar || ''),
        JSON.stringify(Array.isArray(profile.links) ? profile.links : [])
      ]
    );

    for (let i = 0; i < groups.length; i++) {
      const g = groups[i] || {};
      const gid = String(g.id || ('g' + (i + 1)));
      await conn.query(
        'INSERT INTO nav_groups (id, name, sort_order, collapsed, column_index) VALUES (?, ?, ?, ?, ?)',
        [gid, String(g.name || ''), i, g.collapsed ? 1 : 0, Number(g.column) || 0]
      );

      const links = Array.isArray(g.links) ? g.links : [];
      for (let j = 0; j < links.length; j++) {
        const l = links[j] || {};
        await conn.query(
          `INSERT INTO nav_links (id, group_id, title, url, favicon, is_rss, sort_order)
           VALUES (?, ?, ?, ?, ?, ?, ?)`,
          [
            String(l.id || (gid + '_l' + (j + 1))),
            gid,
            String(l.title || ''),
            String(l.url || ''),
            String(l.favicon || ''),
            l.rss ? 1 : 0,
            j
          ]
        );
      }
    }

    await conn.commit();
  } catch (e) {
    await conn.rollback();
    throw e;
  } finally {
    conn.release();
  }
}

// 整份覆盖写入。库表被删掉时重建一次再整体重写，避免白改一场
async function saveNav(data) {
  await init();
  try {
    return await writeAll(data);
  } catch (e) {
    if (!isLost(e)) throw e;
    pool = null;
    ready = null;
    await init();
    return writeAll(data);
  }
}

/* ---------------- 账号与会话 ---------------- */

async function loadAccount() {
  const rows = await q('SELECT * FROM nav_account WHERE id = 1');
  return rows.length ? rows[0] : null;
}

async function saveAccount(a) {
  await q(
    `INSERT INTO nav_account (id, username, password_hash, salt) VALUES (1, ?, ?, ?)
     ON DUPLICATE KEY UPDATE
       username = VALUES(username),
       password_hash = VALUES(password_hash),
       salt = VALUES(salt)`,
    [String(a.user || ''), String(a.hash || ''), String(a.salt || '')]
  );
}

async function createSession(token, expiresAt) {
  await q(
    'INSERT INTO nav_sessions (token, expires_at) VALUES (?, ?)',
    [String(token), expiresAt]
  );
}

// 会话有效则续期，返回是否仍然登录；过期或不存在都算未登录
async function touchSession(token, expiresAt) {
  const rows = await q(
    'SELECT token FROM nav_sessions WHERE token = ? AND expires_at > NOW()',
    [String(token)]
  );
  if (!rows.length) return false;
  await q('UPDATE nav_sessions SET expires_at = ? WHERE token = ?', [expiresAt, String(token)]);
  return true;
}

async function deleteSession(token) {
  await q('DELETE FROM nav_sessions WHERE token = ?', [String(token)]);
}

// 撤销除当前会话以外的所有登录态（改密码后让其它设备退出）
async function deleteOtherSessions(token) {
  await q('DELETE FROM nav_sessions WHERE token <> ?', [String(token)]);
}

async function purgeSessions() {
  await q('DELETE FROM nav_sessions WHERE expires_at <= NOW()');
}

/* ---------------- 健康检查 ---------------- */

// 只探真伪、不触发重建：否则「库被删了」这个事实会被自己顺手修好而永远看不出来。
// 真正需要数据时该重建自然会重建（见 run），这里的职责是如实回答。
// 除了「通不通」，还要回答「不通是因为什么」——前端据此给出能照着做的提示。
async function health() {
  // 没连上、或连上了但建表 / 写数据没成功过：如实转述上次失败的原因，
  // 而不是笼统说一句「未连接」（否则「没权限建表」会被说成「表不存在」）
  if (!pool || !ready) {
    return Object.assign({ ok: false, database: DB_NAME, target: TARGET }, lastError || {
      code: 'NOT_INIT',
      kind: 'unknown',
      label: KIND_TEXT.unknown,
      stage: '',
      stageText: '',
      reason: '后端还没有成功连上数据库',
      hint: '看后端窗口里的报错，或核对 server/config.json 的 mysql 段。',
      detail: ''
    });
  }
  try {
    await pool.query('SELECT id FROM nav_settings WHERE id = 1');
    await pool.query('SELECT id FROM nav_account WHERE id = 1');
    return { ok: true, database: DB_NAME, target: TARGET };
  } catch (e) {
    return Object.assign({ ok: false, database: DB_NAME, target: TARGET }, diagnose(e, 'load'));
  }
}

module.exports = {
  init: init,
  health: health,
  explain: explain,
  diagnose: diagnose,
  loadNav: loadNav,
  saveNav: saveNav,
  loadAccount: loadAccount,
  saveAccount: saveAccount,
  createSession: createSession,
  touchSession: touchSession,
  deleteSession: deleteSession,
  deleteOtherSessions: deleteOtherSessions,
  purgeSessions: purgeSessions,
  dbName: DB_NAME
};
