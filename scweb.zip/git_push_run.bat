py push.py
pause